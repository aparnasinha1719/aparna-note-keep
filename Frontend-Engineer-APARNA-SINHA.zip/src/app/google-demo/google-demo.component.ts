import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-google-demo',
  templateUrl: './google-demo.component.html',
  styleUrls: ['./google-demo.component.css']
})
export class GoogleDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
