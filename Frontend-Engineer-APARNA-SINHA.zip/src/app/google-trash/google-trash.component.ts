import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-google-trash',
  templateUrl: './google-trash.component.html',
  styleUrls: ['./google-trash.component.css']
})
export class GoogleTrashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
